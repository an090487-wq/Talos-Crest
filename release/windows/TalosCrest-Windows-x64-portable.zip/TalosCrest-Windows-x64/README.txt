Talos Crest - Windows x64 (portable preview)
============================================

How to run
----------
1. Copy this whole folder to your Windows PC (do not move just the .exe).
2. Open the folder and double-click TalosCrest.exe.

Keep TalosCrest.exe, WebView2Loader.dll, and the registry and languages folders
together. Talos reads its 135-extension marketplace and language grammar files
from those folders at startup.

Requirements
------------
- Windows 10 or 11, 64-bit.
- Microsoft Edge WebView2 Runtime. Windows 11 usually includes it. On Windows 10,
  if the app reports that WebView2 is missing, install the "WebView2 Runtime
  (Evergreen)" from Microsoft and run TalosCrest.exe again.

Notes
-----
- This is a portable build: settings and your workspace live under your Windows
  user profile, not in this folder.
- No installation or administrator rights are needed.
- The terminal runs a real shell (PowerShell by default on Windows).
